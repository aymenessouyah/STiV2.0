<?php
$connexion = mysqli_connect("localhost", "root", "");
mysqli_select_db($connexion, "ecole");
?>
<link rel="stylesheet" href="style.css">
<?php
if (isset($_POST["ok"])) {
   $Id = $_POST['Id'];
   // Chaque Id commence par une lettre en majuscule (la Catégorie : A, B, C…)
   $Id = strtoupper(substr($Id, 0, 1)) . substr($Id, 1);
   $Nom_prenom = $_POST['Nom_prenom'];
   $Moyenne = (float)$_POST['Moyenne'];
   $DateNaissance = $_POST['DateNaissance'];

   $req = "INSERT INTO eleves (Id, Nom_prenom, Moyenne, DateNaissance)
           VALUES ('$Id', '$Nom_prenom', $Moyenne, '$DateNaissance')";
   if (mysqli_query($connexion, $req)) {
      echo "Élève ajouté (Id = $Id).";
   } else {
      echo "Erreur : " . mysqli_error($connexion);
   }
}
mysqli_close($connexion);
?>
<p><a href="inscription.html">← Ajouter un autre élève</a></p>