<?php
$connexion = mysqli_connect("localhost", "root", "");
mysqli_select_db($connexion, "ecole");

$req = "SELECT Id, Nom_prenom, Moyenne, DateNaissance FROM eleves ORDER BY Nom_prenom";
$resultat = mysqli_query($connexion, $req);
?>
<link rel="stylesheet" href="style.css">
<h2>📋 Liste des élèves</h2>
<table>
   <tr><th>Id</th><th>Nom et prénom</th><th>Moyenne</th><th>Date de naissance</th></tr>
   <?php while ($ligne = mysqli_fetch_array($resultat)) { ?>
   <tr>
      <td><?php echo $ligne["Id"]; ?></td>
      <td><?php echo $ligne["Nom_prenom"]; ?></td>
      <td><?php echo $ligne["Moyenne"]; ?></td>
      <td><?php echo $ligne["DateNaissance"]; ?></td>
   </tr>
   <?php } ?>
</table>
<p><?php echo mysqli_num_rows($resultat); ?> élève(s) au total.</p>
<?php mysqli_close($connexion); ?>