<?php
$connexion = mysqli_connect("localhost", "root", "");
mysqli_select_db($connexion, "ecole");

if (isset($_POST["ok"])) {
   $Id = $_POST['Id'];
   // Chaque Id commence par une lettre en majuscule (la Catégorie : A, B, C…)
   $Id = strtoupper(substr($Id, 0, 1)) . substr($Id, 1);
   $Moyenne = (float)$_POST['Moyenne'];
   $DateNaissance = $_POST['DateNaissance'];

   $req = "UPDATE eleves
           SET Moyenne = $Moyenne, DateNaissance = '$DateNaissance'
           WHERE Id = '$Id'";
   mysqli_query($connexion, $req);

   if (mysqli_affected_rows($connexion) > 0) {
      echo "Élève $Id mis à jour.";
   } else {
      echo "Aucune ligne modifiée (Id introuvable ou valeurs identiques).";
   }
}
mysqli_close($connexion);
?>
<link rel="stylesheet" href="style.css">
<h2>✏️ Mise à jour d'un élève</h2>
<form method="post" onsubmit="return validerModification()">
   <label>Id de l'élève (ex. A01) :</label>
   <input type="text" id="Id" name="Id"><br>

   <label>Nouvelle moyenne :</label>
   <input type="number" id="Moyenne" name="Moyenne" step="0.01"><br>

   <label>Nouvelle date de naissance :</label>
   <input type="date" id="DateNaissance" name="DateNaissance"><br>

   <p id="message"></p>

   <input type="submit" name="ok" value="Mettre à jour">
   <input type="reset" value="Effacer">
</form>
<script src="validation.js"></script>