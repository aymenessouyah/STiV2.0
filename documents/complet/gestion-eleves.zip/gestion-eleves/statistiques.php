<!DOCTYPE html>
<html lang="fr">
<head>
   <meta charset="utf-8">
   <title>Statistiques des élèves</title>
   <link rel="stylesheet" href="style.css">
</head>
<body>

<h1>📊 Statistiques des élèves</h1>

<?php
$connexion = mysqli_connect("localhost", "root", "", "ecole");
if (!$connexion) {
   die("Erreur de connexion : " . mysqli_connect_error());
}

$total = mysqli_query($connexion, "SELECT COUNT(*) AS nb FROM eleves");
$ligneTotal = mysqli_fetch_array($total);

if ($ligneTotal["nb"] > 0) {

   $moy = mysqli_query($connexion, "SELECT AVG(Moyenne) AS m FROM eleves");
   $ligneMoy = mysqli_fetch_array($moy);

   $max = mysqli_query($connexion, "SELECT Nom_prenom, Moyenne FROM eleves ORDER BY Moyenne DESC LIMIT 1");
   $ligneMax = mysqli_fetch_array($max);

   $r1 = mysqli_query($connexion, "SELECT COUNT(*) AS nb FROM eleves WHERE Moyenne >= 10");
   $l1 = mysqli_fetch_array($r1);

   $r2 = mysqli_query($connexion, "SELECT COUNT(*) AS nb FROM eleves WHERE Moyenne < 10");
   $l2 = mysqli_fetch_array($r2);
?>
   <table>
      <tr><td>Nombre d'élèves</td><td><?php echo $ligneTotal["nb"]; ?></td></tr>
      <tr><td>Moyenne générale</td><td><?php echo round($ligneMoy["m"], 2); ?></td></tr>
      <tr><td>Meilleure moyenne</td><td><?php echo $ligneMax["Nom_prenom"] . " (" . $ligneMax["Moyenne"] . ")"; ?></td></tr>
      <tr><td>Admis</td><td><?php echo $l1["nb"]; ?></td></tr>
      <tr><td>Non admis</td><td><?php echo $l2["nb"]; ?></td></tr>
   </table>

   <h2>Âge et anniversaire de chaque élève</h2>
   <table>
      <tr><th>Nom</th><th>Prénom</th><th>Date de naissance</th><th>Âge</th><th>Prochain anniversaire</th></tr>
<?php
   $liste = mysqli_query($connexion, "SELECT Nom_prenom, DateNaissance FROM eleves ORDER BY Nom_prenom");
   $a = date("Y");
   $m = date("n");
   $j = date("j");

   while ($ligne = mysqli_fetch_array($liste)) {

      // Nom et Prénom sont séparés par un espace dans Nom_prenom
      $partiesNom = explode(" ", $ligne["Nom_prenom"], 2);
      $Nom = $partiesNom[0];
      $Prenom = isset($partiesNom[1]) ? $partiesNom[1] : "";

      if (empty($ligne["DateNaissance"])) {
         $texteAge = "—";
         $texteAnniv = "—";
      } else {
         // Date de naissance : AAAA-MM-JJ
         $partie = explode("-", $ligne["DateNaissance"]);
         $an = (int)$partie[0];
         $mn = (int)$partie[1];
         $jn = (int)$partie[2];

         // Âge : années, mois, jours
         $ans = $a - $an;
         $mois = $m - $mn;
         $jours = $j - $jn;
         if ($jours < 0) {
            $mois = $mois - 1;
            $jours = $jours + date("t", mktime(0, 0, 0, $m - 1, 1, $a));
         }
         if ($mois < 0) {
            $ans = $ans - 1;
            $mois = $mois + 12;
         }
         $texteAge = "$ans an(s), $mois mois, $jours jour(s)";

         // Prochain anniversaire : cette année, sinon l'année prochaine
         $anneeProchain = $a;
         if (mktime(0, 0, 0, $mn, $jn, $a) < mktime(0, 0, 0, $m, $j, $a)) {
            $anneeProchain = $a + 1;
         }
         $resteMois = ($anneeProchain - $a) * 12 + $mn - $m;
         $resteJours = $jn - $j;
         if ($resteJours < 0) {
            $resteMois = $resteMois - 1;
            $resteJours = $resteJours + date("t", mktime(0, 0, 0, $mn - 1, 1, $anneeProchain));
         }
         if ($resteMois == 0 && $resteJours == 0) {
            $texteAnniv = "C'est aujourd'hui son anniversaire !";
         } else {
            $texteAnniv = "Il reste $resteMois mois et $resteJours jours avant l'anniversaire";
         }
      }
?>
      <tr>
         <td><?php echo $Nom; ?></td>
         <td><?php echo $Prenom; ?></td>
         <td><?php echo $ligne["DateNaissance"]; ?></td>
         <td><?php echo $texteAge; ?></td>
         <td><?php echo $texteAnniv; ?></td>
      </tr>
<?php
   }
?>
   </table>

   <h2>Liste des élèves par Catégorie</h2>
   <table>
      <tr><th>Catégorie</th><th>Nom</th><th>Prénom</th><th>Moyenne</th></tr>
<?php
   // Tri par Catégorie (A, B, C…) : la Catégorie est la première lettre de l'Id
   $parCategorie = mysqli_query($connexion, "SELECT Id, Nom_prenom, Moyenne FROM eleves ORDER BY LEFT(Id, 1), Nom_prenom");
   while ($ligne = mysqli_fetch_array($parCategorie)) {
      $Categorie = substr($ligne["Id"], 0, 1);
      $partiesNom = explode(" ", $ligne["Nom_prenom"], 2);
      $Nom = $partiesNom[0];
      $Prenom = isset($partiesNom[1]) ? $partiesNom[1] : "";
?>
      <tr>
         <td class="cat-<?php echo $Categorie; ?>"><?php echo $Categorie; ?></td>
         <td><?php echo $Nom; ?></td>
         <td><?php echo $Prenom; ?></td>
         <td><?php echo $ligne["Moyenne"]; ?></td>
      </tr>
<?php
   }
?>
   </table>
<?php
} else {
   echo "<p>Aucun élève dans la table.</p>";
}

mysqli_close($connexion);
?>

</body>
</html>