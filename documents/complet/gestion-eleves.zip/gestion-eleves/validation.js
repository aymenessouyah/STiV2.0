// ===== validation.js : contrôler la saisie avant l'envoi =====
// Variables déclarées avec let ; messages avec innerHTML et alert()

function afficherErreur(texte) {
   let message = document.getElementById("message");
   message.innerHTML = texte; // message affiché dans la page
   alert(texte);              // ... et dans une boîte de dialogue
   return false;              // l'envoi du formulaire est annulé
}

function commenceParMajuscule(texte) {
   return texte.length > 0 && texte[0] >= "A" && texte[0] <= "Z";
}

function dateDansLePasse(valeur) {
   if (valeur == "") return false;
   let saisie = new Date(valeur);
   let aujourdHui = new Date();
   return saisie <= aujourdHui;
}

// Éliminer les espaces superflus : au début, à la fin,
// et plusieurs espaces de suite remplacés par un seul
function nettoyerNomPrenom(valeur) {
   return valeur.trim().replace(/\s+/g, " ");
}

// Nom_prenom correct : uniquement des lettres (accentuées acceptées)
// et des espaces, avec un nombre de mots entre 2 et 5
function nomPrenomCorrect(valeur) {
   let lettresEtEspaces = /^[A-Za-zÀ-ÖØ-öø-ÿ ]+$/;
   if (!lettresEtEspaces.test(valeur)) return false;
   let mots = valeur.split(" ");
   return mots.length >= 2 && mots.length <= 5;
}

// Contrôles communs : Id, Moyenne, DateNaissance
function controlesCommuns() {
   let Id = document.getElementById("Id").value;
   let Moyenne = document.getElementById("Moyenne").value;
   let DateNaissance = document.getElementById("DateNaissance").value;
   let message = document.getElementById("message");

   if (!commenceParMajuscule(Id)) {
      return afficherErreur("Erreur : l'Id doit commencer par une lettre en majuscule.");
   }
   if (Moyenne == "" || isNaN(Moyenne) || Moyenne < 0 || Moyenne > 20) {
      return afficherErreur("Erreur : la Moyenne doit être un nombre entre 0 et 20.");
   }
   if (!dateDansLePasse(DateNaissance)) {
      return afficherErreur("Erreur : la Date de naissance doit être remplie et ne pas être dans le futur.");
   }
   message.innerHTML = "";
   return true;
}

// Page inscription.html : on contrôle aussi le Nom_prenom
function validerInscription() {
   let champNom = document.getElementById("Nom_prenom");
   let NomPrenom = nettoyerNomPrenom(champNom.value);
   champNom.value = NomPrenom; // c'est le nom nettoyé qui sera envoyé
   if (!nomPrenomCorrect(NomPrenom)) {
      return afficherErreur("Erreur : le Nom et le Prénom ne doivent contenir que des lettres et des espaces, avec 2 à 5 mots (ex. Benali Amine).");
   }
   return controlesCommuns();
}

// Page modifier.php
function validerModification() {
   return controlesCommuns();
}