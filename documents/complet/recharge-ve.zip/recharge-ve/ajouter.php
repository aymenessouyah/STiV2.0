<?php
$connexion = mysqli_connect("localhost", "root", "");
mysqli_select_db($connexion, "station");
?>
<link rel="stylesheet" href="style.css">
<?php
if (isset($_POST["ok"])) {
   $Id = $_POST['Id'];
   // Chaque Id commence par une lettre en majuscule (le type de recharge : L, N, R, U)
   $Id = strtoupper(substr($Id, 0, 1)) . substr($Id, 1);
   $Nom_prenom = $_POST['Nom_prenom'];
   $Kwh = (float)$_POST['Kwh'];
   $DateRecharge = $_POST['DateRecharge'];

   $req = "INSERT INTO recharges (Id, Nom_prenom, Kwh, DateRecharge)
           VALUES ('$Id', '$Nom_prenom', $Kwh, '$DateRecharge')";
   if (mysqli_query($connexion, $req)) {
      echo "Recharge enregistrée (Id = $Id).";
   } else {
      echo "Erreur : " . mysqli_error($connexion);
   }
}
mysqli_close($connexion);
?>
<p><a href="inscription.html">← Enregistrer une autre recharge</a></p>
