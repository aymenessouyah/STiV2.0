<?php
$connexion = mysqli_connect("localhost", "root", "");
mysqli_select_db($connexion, "station");

if (isset($_POST["ok"])) {
   $Id = $_POST['Id'];
   // Chaque Id commence par une lettre en majuscule (le type de recharge : L, N, R, U)
   $Id = strtoupper(substr($Id, 0, 1)) . substr($Id, 1);
   $Kwh = (float)$_POST['Kwh'];
   $DateRecharge = $_POST['DateRecharge'];

   $req = "UPDATE recharges
           SET Kwh = $Kwh, DateRecharge = '$DateRecharge'
           WHERE Id = '$Id'";
   mysqli_query($connexion, $req);

   if (mysqli_affected_rows($connexion) > 0) {
      echo "Recharge $Id mise à jour.";
   } else {
      echo "Aucune ligne modifiée (Id introuvable ou valeurs identiques).";
   }
}
mysqli_close($connexion);
?>
<link rel="stylesheet" href="style.css">
<h2>✏️ Mise à jour d'une recharge</h2>
<form method="post" onsubmit="return validerModification()">
   <label>Id de la recharge (ex. R01) :</label>
   <input type="text" id="Id" name="Id"><br>

   <label>Nouvelle énergie (kWh) :</label>
   <input type="number" id="Kwh" name="Kwh" step="0.01"><br>

   <label>Nouvelle date de recharge :</label>
   <input type="date" id="DateRecharge" name="DateRecharge"><br>

   <p id="message"></p>

   <input type="submit" name="ok" value="Mettre à jour">
   <input type="reset" value="Effacer">
</form>
<script src="validation.js"></script>
