-- Base « biblio_lycee » : bibliothèque du lycée (ressource fournie aux élèves)
CREATE DATABASE IF NOT EXISTS biblio_lycee CHARACTER SET utf8mb4;
SET NAMES utf8mb4;
USE biblio_lycee;

DROP TABLE IF EXISTS Emprunt;
DROP TABLE IF EXISTS Livre;
DROP TABLE IF EXISTS Categorie;

CREATE TABLE Categorie (
  idCateg INT PRIMARY KEY,
  nomCateg VARCHAR(40) NOT NULL
);

CREATE TABLE Livre (
  idLivre INT AUTO_INCREMENT PRIMARY KEY,
  titre VARCHAR(80) NOT NULL,
  auteur VARCHAR(50),
  anneeEdition INT,
  dispo INT DEFAULT 1,          -- 1 : disponible, 0 : emprunté
  idCateg INT,
  FOREIGN KEY (idCateg) REFERENCES Categorie(idCateg)
);

INSERT INTO Categorie VALUES (1, 'Roman'), (2, 'Science'), (3, 'Informatique'), (4, 'Histoire');

INSERT INTO Livre (idLivre, titre, auteur, anneeEdition, dispo, idCateg) VALUES
  (1, 'Les Misérables', 'Victor Hugo', 1862, 1, 1),
  (2, 'Le Petit Prince', 'Antoine de Saint-Exupéry', 1943, 0, 1),
  (3, 'Une brève histoire du temps', 'Stephen Hawking', 1988, 1, 2),
  (4, 'Initiation au HTML5 et CSS3', 'Collectif', 2019, 1, 3),
  (5, 'Apprendre PHP et MySQL', 'Collectif', 2018, 0, 3),
  (6, 'Histoire de la Tunisie', 'Collectif', 2005, 1, 4),
  (7, 'Atlas historique du Maghreb', 'Collectif', 2012, 1, 4),
  (8, 'Les bases de la physique', 'Collectif', 2016, 1, 2);
