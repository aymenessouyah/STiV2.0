<?php
  require ("connexion.php");
  $cnx = mysqli_connect($host, $user, $pass, $base) or die("Problème de connexion");
  mysqli_query($cnx, "set names utf8mb4");

  $titre = addslashes($_POST["titre"]);
  $auteur = addslashes($_POST["auteur"]);
  $annee = intval($_POST["anneeEdition"]);
  $pages = intval($_POST["nbPages"]);
  $categ = intval($_POST["idCateg"]);

  mysqli_query($cnx, "insert into Livre (titre, auteur, anneeEdition, nbPages, idCateg)
                      values ('$titre', '$auteur', $annee, $pages, $categ)");
  $res = mysqli_query($cnx, "select last_insert_id()");
  $lig = mysqli_fetch_row($res);
  echo "Livre ajouté sous le numéro " . $lig[0] . ".";
  echo " <a href='liste.php'>Voir la liste</a>";
?>
