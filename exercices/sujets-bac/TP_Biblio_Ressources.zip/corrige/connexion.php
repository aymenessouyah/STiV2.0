<?php
  // Paramètres d'accès à la base (à adapter à votre serveur local)
  $host = "localhost";
  $user = "root";
  $pass = "";
  $base = "biblio_lycee";
?>
