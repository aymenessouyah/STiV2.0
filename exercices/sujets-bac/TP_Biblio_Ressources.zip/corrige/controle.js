// retourne true si v est un entier compris entre min et max
function estEntier(v, min, max) {
  if (v == "" || isNaN(v)) return false;
  var n = Number(v);
  return n == Math.floor(n) && n >= min && n <= max;
}

function verifAjout() {
  var titre = document.F.titre.value;
  var annee = document.F.anneeEdition.value;
  var pages = document.F.nbPages.value;
  var categ = document.F.idCateg.value;

  if (titre.trim() == "") {
    alert("Le titre est obligatoire");
    return false;
  }
  if (!estEntier(annee, 1500, 2100)) {
    alert("L’année d’édition doit être comprise entre 1500 et 2100");
    return false;
  }
  if (!estEntier(pages, 1, 5000)) {
    alert("Le nombre de pages doit être compris entre 1 et 5000");
    return false;
  }
  if (categ == "") {
    alert("Choisissez une catégorie");
    return false;
  }
  return true;
}

function verifModif() {
  var id = document.G.idLivre.value;
  var pages = document.G.nbPages.value;
  var choix = document.G.dispo[0].checked || document.G.dispo[1].checked;

  if (!estEntier(id, 1, 100000)) {
    alert("Le numéro du livre doit être un entier positif");
    return false;
  }
  if (!choix) {
    alert("Choisissez la disponibilité");
    return false;
  }
  if (pages != "" && !estEntier(pages, 1, 5000)) {
    alert("Le nombre de pages doit être compris entre 1 et 5000");
    return false;
  }
  return true;
}
