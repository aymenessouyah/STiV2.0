-- Solution des changements LDD et LMD (base biblio_lycee)
SET NAMES utf8mb4;
USE biblio_lycee;

-- LDD
ALTER TABLE Livre ADD nbPages INT;
ALTER TABLE Livre ADD CHECK (anneeEdition BETWEEN 1500 AND 2100);
ALTER TABLE Categorie ADD UNIQUE (nomCateg);
CREATE TABLE Emprunt (
  idEmprunt INT AUTO_INCREMENT PRIMARY KEY,
  idLivre INT,
  nomEleve VARCHAR(50),
  dateEmprunt DATE,
  dateRetour DATE,
  FOREIGN KEY (idLivre) REFERENCES Livre(idLivre)
);

-- LMD
INSERT INTO Categorie VALUES (5, 'Poésie'), (6, 'Bande dessinée');
UPDATE Livre SET nbPages = 250 WHERE nbPages IS NULL;
UPDATE Livre SET nbPages = 96 WHERE titre = 'Le Petit Prince';
INSERT INTO Livre (titre, auteur, anneeEdition, dispo, idCateg, nbPages) VALUES
  ('Recueil de poèmes', 'Collectif', 2001, 1, 5, 120),
  ('Aventures en bande dessinée', 'Collectif', 2014, 1, 6, 64);
INSERT INTO Emprunt (idLivre, nomEleve, dateEmprunt) VALUES (2, 'Mariem', '2026-11-10'), (5, 'Slim', '2026-11-12');
UPDATE Livre SET dispo = 0 WHERE idLivre IN (SELECT idLivre FROM Emprunt WHERE dateRetour IS NULL);
DELETE FROM Livre WHERE titre = 'Aventures en bande dessinée';
DELETE FROM Categorie WHERE idCateg = 6;
