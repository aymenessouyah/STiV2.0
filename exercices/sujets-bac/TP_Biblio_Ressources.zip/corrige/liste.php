<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Liste des livres</title>
  <link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
  <h1>Liste des livres</h1>
  <nav><a href="index.html">Accueil</a> <a href="ajouter.html">Ajouter un livre</a> <a href="modifier.html">Modifier un livre</a></nav>
<?php
  require ("connexion.php");
  $cnx = mysqli_connect($host, $user, $pass, $base) or die("Problème de connexion");
  mysqli_query($cnx, "set names utf8mb4");

  // filtres : une ligne de liens construite à partir de la table Categorie
  echo "<p>Catégories : <a href='liste.php'>Toutes</a>";
  $rc = mysqli_query($cnx, "select idCateg, nomCateg from Categorie order by nomCateg");
  while ($c = mysqli_fetch_array($rc)) {
    echo " | <a href='liste.php?categ=" . $c["idCateg"] . "'>" . $c["nomCateg"] . "</a>";
  }
  echo "</p>";

  $sql = "select idLivre, titre, auteur, anneeEdition, nbPages, nomCateg, dispo
          from Livre L, Categorie C
          where L.idCateg = C.idCateg";
  if (isset($_GET["categ"]) && $_GET["categ"] != "") {
    $sql = $sql . " and L.idCateg = " . intval($_GET["categ"]);
  }
  $sql = $sql . " order by titre";
  $res = mysqli_query($cnx, $sql);

  echo "<table>";
  echo "<tr><th>N°</th><th>Titre</th><th>Auteur</th><th>Année</th><th>Pages</th><th>Catégorie</th><th>État</th></tr>";
  while ($l = mysqli_fetch_array($res)) {
    if ($l["dispo"] == 1) {
      $etat = "Disponible";
      $classe = "";
    } else {
      $etat = "Emprunté";
      $classe = "emprunte";
    }
    echo "<tr class='$classe'>";
    echo "<td>" . $l["idLivre"] . "</td><td>" . $l["titre"] . "</td><td>" . $l["auteur"] . "</td>";
    echo "<td>" . $l["anneeEdition"] . "</td><td>" . $l["nbPages"] . "</td><td>" . $l["nomCateg"] . "</td>";
    echo "<td>" . $etat . "</td>";
    echo "</tr>";
  }
  echo "</table>";
  echo "<p>" . mysqli_num_rows($res) . " livre(s) affiché(s).</p>";
?>
</body>
</html>
