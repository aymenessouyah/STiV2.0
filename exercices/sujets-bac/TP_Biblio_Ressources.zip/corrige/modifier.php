<?php
  require ("connexion.php");
  $cnx = mysqli_connect($host, $user, $pass, $base) or die("Problème de connexion");
  mysqli_query($cnx, "set names utf8mb4");

  $id = intval($_POST["idLivre"]);
  $dispo = intval($_POST["dispo"]);
  $pages = $_POST["nbPages"];

  $res = mysqli_query($cnx, "select idLivre from Livre where idLivre = $id");
  if (mysqli_num_rows($res) == 0) {
    echo "Livre introuvable.";
  } else {
    mysqli_query($cnx, "update Livre set dispo = $dispo where idLivre = $id");
    $n = mysqli_affected_rows($cnx);
    if ($pages != "") {
      $pages = intval($pages);
      mysqli_query($cnx, "update Livre set nbPages = $pages where idLivre = $id");
    }
    echo "Livre n° $id mis à jour.";
    if ($n == 0) {
      echo " (la disponibilité était déjà celle demandée)";
    }
  }
  echo " <a href='liste.php'>Voir la liste</a>";
?>
