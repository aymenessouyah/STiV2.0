<?php
  require ("connexion.php");
  $cnx = mysqli_connect($host, $user, $pass, $base) or die("Problème de connexion");
  mysqli_query($cnx, "set names utf8mb4");

  // TODO 3.1 : récupérer titre, auteur, anneeEdition, nbPages et idCateg (méthode POST)
  //            protéger les chaînes avec addslashes(...) et convertir les nombres avec intval(...)

  // TODO 3.1 : insérer le livre dans la table Livre (le champ dispo prend sa valeur par défaut)

  // TODO 3.1 : afficher "Livre ajouté sous le numéro N." (N = résultat de la requête select last_insert_id(),
  //            lu avec mysqli_fetch_row)
  //            puis un lien vers liste.php
?>
