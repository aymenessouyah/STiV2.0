// retourne true si v est un entier compris entre min et max
function estEntier(v, min, max) {
  // TODO 1 : retourner false si v est vide ou n'est pas un nombre (isNaN),
  //          sinon retourner true si Number(v) est un entier compris entre min et max
  //          (un entier vérifie : n == Math.floor(n))
}

function verifAjout() {
  var titre = document.F.titre.value;
  var annee = document.F.anneeEdition.value;
  var pages = document.F.nbPages.value;
  var categ = document.F.idCateg.value;

  // TODO 2 : titre obligatoire (ignorer les espaces avec trim())
  if ( ......................... ) {
    alert("Le titre est obligatoire");
    return false;
  }
  // TODO 3 : année entre 1500 et 2100, nombre de pages entre 1 et 5000 (utiliser estEntier)
  if ( ......................... ) {
    alert("L’année d’édition doit être comprise entre 1500 et 2100");
    return false;
  }
  if ( ......................... ) {
    alert("Le nombre de pages doit être compris entre 1 et 5000");
    return false;
  }
  // TODO 4 : une catégorie doit être choisie
  if ( ......................... ) {
    alert("Choisissez une catégorie");
    return false;
  }
  return true;
}

function verifModif() {
  var id = document.G.idLivre.value;
  var pages = document.G.nbPages.value;
  // TODO 5 : choix vaut true si l'un des deux boutons radio (document.G.dispo[0] ou [1]) est coché
  var choix = .........................;

  if (!estEntier(id, 1, 100000)) {
    alert("Le numéro du livre doit être un entier positif");
    return false;
  }
  if (!choix) {
    alert("Choisissez la disponibilité");
    return false;
  }
  // le nombre de pages est facultatif : on ne le contrôle que s'il est rempli
  if (pages != "" && !estEntier(pages, 1, 5000)) {
    alert("Le nombre de pages doit être compris entre 1 et 5000");
    return false;
  }
  return true;
}
