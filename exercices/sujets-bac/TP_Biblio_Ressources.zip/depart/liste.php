<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Liste des livres</title>
  <link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
  <h1>Liste des livres</h1>
  <nav><a href="index.html">Accueil</a> <a href="ajouter.html">Ajouter un livre</a> <a href="modifier.html">Modifier un livre</a></nav>
<?php
  require ("connexion.php");
  $cnx = mysqli_connect($host, $user, $pass, $base) or die("Problème de connexion");
  mysqli_query($cnx, "set names utf8mb4");

  // filtres : une ligne de liens construite à partir de la table Categorie
  echo "<p>Catégories : <a href='liste.php'>Toutes</a>";
  $rc = mysqli_query($cnx, "select idCateg, nomCateg from Categorie order by nomCateg");
  while ($c = mysqli_fetch_array($rc)) {
    echo " | <a href='liste.php?categ=" . $c["idCateg"] . "'>" . $c["nomCateg"] . "</a>";
  }
  echo "</p>";

  // TODO 3.3 (a) : construire la requête $sql : idLivre, titre, auteur, anneeEdition, nbPages, nomCateg, dispo
  //                des tables Livre et Categorie (jointure), triés par titre.
  //                Si l'URL contient ?categ=N (isset($_GET["categ"])), ne garder que les livres de la catégorie N.
  // TODO 3.3 (b) : exécuter la requête, puis afficher un tableau HTML (une ligne par livre) :
  //                colonnes N°, Titre, Auteur, Année, Pages, Catégorie, État
  //                État = "Disponible" si dispo vaut 1, sinon "Emprunté" avec la classe CSS "emprunte" sur la ligne <tr>
  // TODO 3.3 (c) : afficher sous le tableau : "N livre(s) affiché(s)." (mysqli_num_rows)
?>
</body>
</html>
