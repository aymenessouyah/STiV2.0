<?php
  require ("connexion.php");
  $cnx = mysqli_connect($host, $user, $pass, $base) or die("Problème de connexion");
  mysqli_query($cnx, "set names utf8mb4");

  // TODO 3.2 : récupérer idLivre, dispo et nbPages (méthode POST) ; convertir idLivre et dispo avec intval

  // TODO 3.2 : vérifier que le livre existe (select + mysqli_num_rows)
  //            - s'il n'existe pas : afficher "Livre introuvable."
  //            - sinon : mettre à jour dispo (mysqli_affected_rows donne le nombre de lignes modifiées) ;
  //              si nbPages n'est pas vide, mettre aussi à jour nbPages ; puis afficher "Livre n° N mis à jour."
  //              (ajouter "(la disponibilité était déjà celle demandée)" si aucune ligne n'a été modifiée)

  // puis un lien vers liste.php
?>
